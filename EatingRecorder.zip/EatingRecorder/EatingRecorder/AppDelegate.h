//
//  AppDelegate.h
//  EatingRecorder
//
//  Created by GUEST on 2/29/16.
//  Copyright © 2016 Edward Kuo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

