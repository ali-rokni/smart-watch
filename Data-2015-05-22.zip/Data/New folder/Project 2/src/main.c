/*----------------------------------------------------------------------------
 *----------------------------------------------------------------------------*/
#include <MKL25Z4.H>
#include <stdio.h>
#include "gpio_defs.h"
#include "LEDs.h"


//extern volatile unsigned switch_pressed;
extern void init_debug_signals(void);
extern void LED_G_N_ON(void);
/*----------------------------------------------------------------------------
  MAIN function
 *----------------------------------------------------------------------------*/
int main (void) {
	init_RGB_LEDs();
//	init_debug_signals();
//	__enable_irq();
	
	
while (1) {
	//	DEBUG_PORT->PTOR = MASK(DBG_MAIN_POS);

	    LED_R_N_ON();	
	
			LED_Y_N_ON(); 
		
		  LED_G_N_ON();
			LED_G_S_OFF();
}	
}

/*void PORTD_IRQHandler(void) { 
	DEBUG_PORT->PSOR = MASK(DBG_ISR_POS);
	// clear pending interrupts
	NVIC_ClearPendingIRQ(PORTD_IRQn);
	if ((PORTD->ISFR & MASK(SW_POS1))) {
	count1++;
	}
	if ((PORTD->ISFR & MASK(SW_POS2))) {
	count2++;
	}
	if ((PORTD->ISFR & MASK(SW_POS3))) {
	count3++;
	}
	// clear status flags 
	PORTD->ISFR = 0xffffffff;
	DEBUG_PORT->PCOR = MASK(DBG_ISR_POS);
}*/
// *******************************ARM University Program Copyright � ARM Ltd 2013*************************************   
