#include <MKL25Z4.H>
#include "LEDs.h"
#include "gpio_defs.h"

/*void delay(int a)
{
while(a>=0)
{
DEBUG_PORT->PTOR = MASK(DBG_MAIN_POS);
--a;
}
}*/


void init_RGB_LEDs(void) {
	// Enable clock to ports B and D
	SIM->SCGC5 |= SIM_SCGC5_PORTA_MASK | SIM_SCGC5_PORTC_MASK | SIM_SCGC5_PORTD_MASK;;
	
	// Make 3 pins GPIO
	PORTA->PCR[R_LED_N] &= ~PORT_PCR_MUX_MASK;          
	PORTA->PCR[R_LED_N] |= PORT_PCR_MUX(1);	
	PORTA->PCR[Y_LED_N] &= ~PORT_PCR_MUX_MASK;          
	PORTA->PCR[Y_LED_N] |= PORT_PCR_MUX(1);          
	PORTA->PCR[G_LED_N] &= ~PORT_PCR_MUX_MASK;          
	PORTA->PCR[G_LED_N] |= PORT_PCR_MUX(1);          
	
	PORTA->PCR[R_LED_E] &= ~PORT_PCR_MUX_MASK;          
	PORTA->PCR[R_LED_E] |= PORT_PCR_MUX(1);	
	PORTA->PCR[Y_LED_E] &= ~PORT_PCR_MUX_MASK;          
	PORTA->PCR[Y_LED_E] |= PORT_PCR_MUX(1);          
	PORTC->PCR[G_LED_E] &= ~PORT_PCR_MUX_MASK;          
	PORTC->PCR[G_LED_E] |= PORT_PCR_MUX(1);          
	
	PORTD->PCR[R_LED_S] &= ~PORT_PCR_MUX_MASK;          
	PORTD->PCR[R_LED_S] |= PORT_PCR_MUX(1);	
	PORTD->PCR[Y_LED_S] &= ~PORT_PCR_MUX_MASK;          
	PORTD->PCR[Y_LED_S] |= PORT_PCR_MUX(1);          
	PORTD->PCR[G_LED_S] &= ~PORT_PCR_MUX_MASK;          
	PORTD->PCR[G_LED_S] |= PORT_PCR_MUX(1);          
	
	PORTD->PCR[R_LED_W] &= ~PORT_PCR_MUX_MASK;          
	PORTD->PCR[R_LED_W] |= PORT_PCR_MUX(1);	
	PORTD->PCR[Y_LED_W] &= ~PORT_PCR_MUX_MASK;          
	PORTD->PCR[Y_LED_W] |= PORT_PCR_MUX(1);          
	PORTC->PCR[G_LED_W] &= ~PORT_PCR_MUX_MASK;          
	PORTC->PCR[G_LED_W] |= PORT_PCR_MUX(1);          
	
	// Set ports to outputs
	PTA->PDDR |= MASK(R_LED_N) | MASK(Y_LED_N) | MASK(G_LED_N) | MASK(R_LED_E) | MASK(Y_LED_E);
	PTD->PDDR |= MASK(R_LED_S) | MASK(Y_LED_S) | MASK(G_LED_S) | MASK(R_LED_W) | MASK(Y_LED_W);
	PTC->PDDR |= MASK(G_LED_E) | MASK(G_LED_W);
	
/*	PTA->PSOR = MASK(R_LED_N);
	PTA->PSOR = MASK(G_LED_N);
	PTA->PSOR = MASK(Y_LED_N);
	PTA->PSOR = MASK(R_LED_E);
	PTA->PSOR = MASK(Y_LED_E);
	
	PTD->PSOR = MASK(R_LED_S);
	PTD->PSOR = MASK(Y_LED_S);
	PTD->PSOR = MASK(G_LED_S);
	PTD->PSOR = MASK(R_LED_W);
	PTD->PSOR = MASK(Y_LED_W);
	
	PTC->PSOR = MASK(G_LED_E);
	PTC->PSOR = MASK(G_LED_W);*/
}

void LED_R_N_ON(void){
		PTA->PCOR = MASK(R_LED_N);
		} 

void LED_Y_N_ON(void){
			PTA->PCOR = MASK(Y_LED_N);
			}

void LED_G_N_ON(void){
			PTA->PCOR = MASK(G_LED_N);
	}
void LED_G_S_OFF(void){
			PTD->PSOR = MASK (G_LED_S);
}
// *******************************ARM University Program Copyright � ARM Ltd 2013*************************************   
