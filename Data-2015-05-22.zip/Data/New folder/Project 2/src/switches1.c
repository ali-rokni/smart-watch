#include <MKL25Z4.H>
#include "switches1.h"
#include "LEDs.h"

volatile unsigned count1=0;

void init_switch1(void) {
	SIM->SCGC5 |=  SIM_SCGC5_PORTD_MASK; /* enable clock for port D */

	/* Select GPIO and enable pull-up resistors and interrupts 
		on falling edges for pins connected to switches */
	PORTD->PCR[SW_POS1] |= PORT_PCR_MUX(1) | PORT_PCR_PS_MASK | PORT_PCR_PE_MASK | PORT_PCR_IRQC(0x0a);
	
	/* Set port D switch bit to inputs */
	PTD->PDDR &= ~MASK(SW_POS1);

	/* Enable Interrupts */
	NVIC_SetPriority(PORTD_IRQn, 64); // 0, 64, 128 or 192
	NVIC_ClearPendingIRQ(PORTD_IRQn); 
	NVIC_EnableIRQ(PORTD_IRQn);
}


// *******************************ARM University Program Copyright � ARM Ltd 2013*************************************   
