#ifndef SWITCHES2_H
#define SWITCHES2_H
#include "gpio_defs.h"

// Switches is on port D for interrupt support
#define SW_POS2 (5)

// Function prototypes
extern void init_switch2(void);

// Shared variables
extern volatile unsigned count2;

#endif
// *******************************ARM University Program Copyright � ARM Ltd 2013*************************************   
