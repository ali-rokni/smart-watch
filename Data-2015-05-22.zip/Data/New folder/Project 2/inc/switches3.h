#ifndef SWITCHES3_H
#define SWITCHES3_H
#include "gpio_defs.h"

// Switches is on port D for interrupt support
#define SW_POS3 (2)

// Function prototypes
extern void init_switch3(void);

// Shared variables
extern volatile unsigned count3;

#endif
// *******************************ARM University Program Copyright � ARM Ltd 2013*************************************   
