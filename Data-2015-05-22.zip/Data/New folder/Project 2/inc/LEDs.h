#ifndef LEDS_H
#define LEDS_H

#define R_LED_N (1)		
#define Y_LED_N (2)	
#define G_LED_N (12)

#define R_LED_E (4)		
#define Y_LED_E (5)	
#define G_LED_E (9)

#define R_LED_S (5)		
#define Y_LED_S (0)	
#define G_LED_S (2)

#define R_LED_W (3)		
#define Y_LED_W (1)	
#define G_LED_W (9)


extern void init_RGB_LEDs(void);
extern void LED_R_N_ON(void);
extern void LED_Y_N_ON(void);
extern void LED_G_N_ON(void);

extern void LED_R_E_ON(void);
extern void LED_Y_E_ON(void);
extern void LED_G_E_ON(void);

extern void LED_R_S_ON(void);
extern void LED_Y_S_ON(void);
extern void LED_G_S_ON(void);

extern void LED_R_W_ON(void);
extern void LED_Y_W_ON(void);
extern void LED_G_W_ON(void);

extern void LED_R_N_OFF(void);
extern void LED_Y_N_OFF(void);
extern void LED_G_N_OFF(void);

extern void LED_R_E_OFF(void);
extern void LED_Y_E_OFF(void);
extern void LED_G_E_OFF(void);

extern void LED_R_S_OFF(void);
extern void LED_Y_S_OFF(void);
extern void LED_G_S_OFF(void);

extern void LED_R_W_OFF(void);
extern void LED_Y_W_OFF(void);
extern void LED_G_W_OFF(void);

#endif


// *******************************ARM University Program Copyright � ARM Ltd 2013*************************************   
