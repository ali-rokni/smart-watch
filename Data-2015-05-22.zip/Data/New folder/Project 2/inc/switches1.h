#ifndef SWITCHES1_H
#define SWITCHES1_H
#include "gpio_defs.h"

// Switches is on port D for interrupt support
#define SW_POS1 (6)

// Function prototypes
extern void init_switch1(void);

// Shared variables
extern volatile unsigned count1;

#endif
// *******************************ARM University Program Copyright � ARM Ltd 2013*************************************   
